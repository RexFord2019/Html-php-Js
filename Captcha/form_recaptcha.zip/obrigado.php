<!DOCTYPE html>
<html lang="pt-br" >
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0,user-scalable=0">
        <title>Obrigado | reCAPTCHA em Formulário</title>

        <!-- DEFINE ESTILO DA PÁGINA -->
        <link rel="stylesheet" href="_form.css">
    </head>
    <body>
        <div class="wrapper" style="text-align: center;">
            <h1>Sua solicitação foi enviada com sucesso! <br>Em breve retornaremos seu contato.</h1>
        </div>
    </body>
</html>